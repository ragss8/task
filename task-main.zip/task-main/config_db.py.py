from pymongo import MongoClient
conn = MongoClient()